import { Component, OnInit } from '@angular/core';
import { UserComponent } from '../user/user.component';
import { HttpClient } from '@angular/common/http';



@Component({
  selector: 'app-user-info',
  standalone: true,
  imports: [],
  templateUrl: './user-info.component.html',
  styleUrl: './user-info.component.css'
})
export class UserInfoComponent implements OnInit {

  userInfo: any;

  constructor(private http: HttpClient) { }

  ngOnInit(): void {
    this.http.get<any>('/userinfo').subscribe(
      response => {
        this.userInfo = response;
      },
      error => {
        console.error('Error fetching user info:', error);
        // Handle error (e.g., display an error message or redirect to login)
      }
    );
  }
}
